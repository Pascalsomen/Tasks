<?php $__env->startSection('content'); ?>

    <h1>Welcome</h1>
    <p class="lead">
        
    </p>
    <hr>

    <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-info">View Tasks</a>
    <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary">Add New Task</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>