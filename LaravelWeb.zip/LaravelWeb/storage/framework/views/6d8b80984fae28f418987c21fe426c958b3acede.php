<?php $__env->startSection('content'); ?>

    

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
 <div class="panel-heading " style="">
 <div class="alert alert-danger">Are you sure you want to delete this Task? 
             <div class="pull-right"> 
            <?php echo Form::open([
                'method' => 'DELETE',
                'route' => ['tasks.destroy', $task->id]
            ]); ?>

            <?php echo Form::submit('Yes', ['class' => 'btn btn-link pull-right']); ?>

            <?php echo Form::close(); ?>


        </div>
        </div>
        <a class="" href="<?php echo e(route('tasks.index')); ?>">No</a>

 </div>
  <div class="panel-body">
    <h3><u> Task Title:</h3></u><br>
    <h3><?php echo e($task->title); ?></h3>
     <h3><u> Task Desc:</h3></u><br>
   <h3><?php echo e($task->description); ?></h3>
    <hr>

 </div>
 <div class="panel-footer">
            
        </div>
       
</div>
            
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>