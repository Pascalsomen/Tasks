<?php $__env->startSection('content'); ?>

    
    
  
<div class="panel panel-default">
 <div class="panel-heading " style="background-color:#045F68;">
<font color="white"><h4> Task List </h4> </font>
 </div>
  <div class="panel-body">
  <?php if(Session::has('flash_message')): ?>
        <div class="alert alert-success fade in">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo e(Session::get('flash_message')); ?>

        </div>
    <?php endif; ?>
<table class="table table-hover">
        <tr><th>Title</th><th>Description</th><th>Action</th></tr>
    <?php foreach($tasks as $task): ?>
    
        <tr><td><?php echo e($task->title); ?></td><td><?php echo e($task->description); ?> </td><td><a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-linkl-right">More </td></tr>

    <?php endforeach; ?>
    </table>
 </div>
 <div class="panel-footer"> 
<a class="btn btn-primary pull-right" href="<?php echo e(route('tasks.create')); ?>">Add New Task</a><br>
<br>
 </div>
</div>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>