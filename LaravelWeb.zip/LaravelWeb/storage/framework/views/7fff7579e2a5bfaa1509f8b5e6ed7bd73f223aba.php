<?php $__env->startSection('content'); ?>

   

    <?php echo Form::model($task, [
    'method' => 'PATCH',
    'route' => ['tasks.update', $task->id]
]); ?>


<div class="panel panel-default">
 <div class="panel-heading " style="background-color:#045F68;">
<font color="white"><h4>Update Task</h4></font>
 </div>
  <div class="panel-body">
<div class="form-group <?php if($errors->get('title')): ?>: has-error <?php endif; ?>">
        <?php echo Form::label('title', 'Title:', ['class' => 'control-label']); ?>

        <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

        <?php if($errors->has('title')): ?>
            <p class="help-block"><?php echo e($errors->first('title')); ?></p>
        <?php endif; ?>
    </div>

    <div class="form-group <?php if($errors->get('description')): ?>: has-error <?php endif; ?>">
        <?php echo Form::label('description', 'Description:', ['class' => 'control-label']); ?>

        <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

        <?php if($errors->has('description')): ?>
            <p class="help-block"><?php echo e($errors->first('description')); ?></p>
        <?php endif; ?>
    </div>
 </div>
 <div class="panel-footer">  <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>


    <?php echo Form::close(); ?>


     <a class="pull-right btn btn-primary" href="<?php echo e(route('tasks.index')); ?>">Back</a> </div>
</div>
    

  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>